package com.Bank_Details;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankDetailsApplicationTests {

	@Test
	void contextLoads() {
	}

}
